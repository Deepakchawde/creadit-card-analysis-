import jwt from "jsonwebtoken";
import { NextRequest } from "next/server";

const SECRET = process.env.JWT_SECRET || "fallback-secret-change-me";

export interface JWTPayload {
  userId: string;
  role: string;
  name: string;
}

export function signToken(payload: JWTPayload): string {
  return jwt.sign(payload, SECRET, { expiresIn: "24h" });
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, SECRET) as JWTPayload;
  } catch {
    return null;
  }
}

export function getTokenFromRequest(req: NextRequest): JWTPayload | null {
  const auth = req.headers.get("authorization");
  if (auth?.startsWith("Bearer ")) {
    return verifyToken(auth.slice(7));
  }
  const cookie = req.cookies.get("token")?.value;
  if (cookie) return verifyToken(cookie);
  return null;
}

export function requireRole(req: NextRequest, roles: string[]): JWTPayload | null {
  const user = getTokenFromRequest(req);
  if (!user) return null;
  if (!roles.includes(user.role)) return null;
  return user;
}
