import Database from "better-sqlite3";
import path from "path";
import bcrypt from "bcryptjs";

let db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (db) return db;

  const dbPath = process.env.DB_PATH || "./abhishek-pricing.db";
  const resolvedPath = path.resolve(process.cwd(), dbPath);
  db = new Database(resolvedPath);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  initSchema(db);
  return db;
}

function initSchema(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      name TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS chemicals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      grade TEXT DEFAULT 'Commercial',
      country TEXT DEFAULT 'Global',
      region TEXT DEFAULT 'Global',
      currency TEXT DEFAULT 'USD',
      unit TEXT DEFAULT 'MT',
      category TEXT DEFAULT 'Petrochemical',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS price_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chemical_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      price REAL NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (chemical_id) REFERENCES chemicals(id) ON DELETE CASCADE,
      UNIQUE(chemical_id, date)
    );

    CREATE TABLE IF NOT EXISTS forecasts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chemical_id INTEGER NOT NULL,
      forecast_date TEXT NOT NULL,
      price REAL NOT NULL,
      confidence_low REAL,
      confidence_high REAL,
      model TEXT DEFAULT 'linear',
      horizon_months INTEGER DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (chemical_id) REFERENCES chemicals(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      action TEXT NOT NULL,
      details TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS supply_chain (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chemical_id INTEGER NOT NULL,
      stage TEXT NOT NULL,
      description TEXT,
      capacity REAL,
      status TEXT DEFAULT 'operational',
      country TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (chemical_id) REFERENCES chemicals(id) ON DELETE CASCADE
    );
  `);

  // Seed super admin if not exists
  const admin = db.prepare("SELECT id FROM users WHERE user_id = ?").get("ADMIN");
  if (!admin) {
    const hash = bcrypt.hashSync("admin123", 10);
    db.prepare(
      "INSERT INTO users (user_id, email, password_hash, role, name) VALUES (?, ?, ?, ?, ?)"
    ).run("ADMIN", "admin@abhishekpricing.com", hash, "superadmin", "Super Admin");
  }

  // Seed sample chemicals
  const chemCount = (db.prepare("SELECT COUNT(*) as cnt FROM chemicals").get() as { cnt: number }).cnt;
  if (chemCount === 0) {
    seedSampleData(db);
  }
}

function seedSampleData(db: Database.Database) {
  const chemicals = [
    { name: "Methanol", grade: "Technical", country: "India", region: "Asia", currency: "USD", unit: "MT", category: "Alcohol" },
    { name: "Ethanol", grade: "Industrial", country: "India", region: "Asia", currency: "USD", unit: "MT", category: "Alcohol" },
    { name: "Acetic Acid", grade: "Glacial", country: "China", region: "Asia", currency: "USD", unit: "MT", category: "Organic Acid" },
    { name: "Ethylene", grade: "Polymer", country: "USA", region: "Americas", currency: "USD", unit: "MT", category: "Olefin" },
    { name: "Propylene", grade: "Chemical", country: "USA", region: "Americas", currency: "USD", unit: "MT", category: "Olefin" },
    { name: "Benzene", grade: "Technical", country: "Germany", region: "Europe", currency: "USD", unit: "MT", category: "Aromatic" },
    { name: "Toluene", grade: "Technical", country: "Germany", region: "Europe", currency: "USD", unit: "MT", category: "Aromatic" },
    { name: "Urea", grade: "Prilled", country: "India", region: "Asia", currency: "USD", unit: "MT", category: "Fertilizer" },
  ];

  const insertChem = db.prepare(
    "INSERT INTO chemicals (name, grade, country, region, currency, unit, category) VALUES (?, ?, ?, ?, ?, ?, ?)"
  );

  const insertPrice = db.prepare(
    "INSERT OR IGNORE INTO price_history (chemical_id, date, price) VALUES (?, ?, ?)"
  );

  // Base prices for each chemical
  const basePrices: Record<string, number> = {
    Methanol: 350, Ethanol: 520, "Acetic Acid": 480,
    Ethylene: 890, Propylene: 760, Benzene: 710,
    Toluene: 680, Urea: 310,
  };

  for (const chem of chemicals) {
    const result = insertChem.run(chem.name, chem.grade, chem.country, chem.region, chem.currency, chem.unit, chem.category);
    const chemId = result.lastInsertRowid as number;

    // Generate 36 months of price history
    const base = basePrices[chem.name] || 400;
    let price = base;
    for (let i = 35; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const dateStr = d.toISOString().slice(0, 7) + "-01";
      // Random walk with trend
      price = price * (1 + (Math.random() - 0.48) * 0.06);
      price = Math.max(price, base * 0.5);
      insertPrice.run(chemId, dateStr, Math.round(price * 100) / 100);
    }
  }
}
