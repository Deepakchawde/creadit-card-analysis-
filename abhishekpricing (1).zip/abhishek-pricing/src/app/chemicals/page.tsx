"use client";
import { useEffect, useState, useCallback, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import AppLayout from "@/components/AppLayout";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine
} from "recharts";

interface Chemical {
  id: number;
  name: string;
  category: string;
  country: string;
  currency: string;
  unit: string;
  latest_price: number;
}

interface PricePoint {
  date: string;
  price: number;
  ma3: number;
}

interface Stats {
  avg_price: number;
  min_price: number;
  max_price: number;
  latest_price: number;
}

interface Forecast {
  date: string;
  price: number;
  confidence_low: number;
  confidence_high: number;
  month: number;
}

interface ForecastMeta {
  trendDirection: string;
  accuracy: string;
  volatility: string;
  lastPrice: number;
}

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];

function ChemicalsPageInner() {
  const searchParams = useSearchParams();
  const compareMode = searchParams.get("compare") === "1";

  const [chemicals, setChemicals] = useState<Chemical[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [compareIds, setCompareIds] = useState<number[]>([]);
  const [prices, setPrices] = useState<PricePoint[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [cagr, setCagr] = useState<string | null>(null);
  const [forecasts, setForecasts] = useState<Forecast[]>([]);
  const [forecastMeta, setForecastMeta] = useState<ForecastMeta | null>(null);
  const [compareData, setCompareData] = useState<Record<string, { date: string; price: number }[]>>({});
  const [chartType, setChartType] = useState<"line" | "area" | "bar">("area");
  const [months, setMonths] = useState(24);
  const [isCompare, setIsCompare] = useState(compareMode);
  const [showForecast, setShowForecast] = useState(false);
  const [loading, setLoading] = useState(false);

  const token = typeof window !== "undefined" ? localStorage.getItem("token") : "";

  useEffect(() => {
    fetch("/api/chemicals", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((d) => {
        setChemicals(d.chemicals || []);
        const idParam = searchParams.get("id");
        if (idParam) setSelectedId(Number(idParam));
        else if (d.chemicals?.length > 0) setSelectedId(d.chemicals[0].id);
      });
  }, [token, searchParams]);

  const loadPrices = useCallback(async (id: number) => {
    setLoading(true);
    const r = await fetch(`/api/prices?chemicalId=${id}&months=${months}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const d = await r.json();
    setPrices(d.prices || []);
    setStats(d.stats);
    setCagr(d.cagr);
    setLoading(false);
  }, [token, months]);

  const loadForecast = useCallback(async (id: number) => {
    const r = await fetch(`/api/forecasts?chemicalId=${id}&horizon=6`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const d = await r.json();
    setForecasts(d.forecasts || []);
    setForecastMeta(d.metadata);
  }, [token]);

  const loadComparison = useCallback(async (ids: number[]) => {
    if (ids.length < 2) return;
    const r = await fetch(`/api/prices?ids=${ids.join(",")}&months=${months}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const d = await r.json();
    setCompareData(d.comparison || {});
  }, [token, months]);

  useEffect(() => {
    if (!isCompare && selectedId) {
      loadPrices(selectedId);
      if (showForecast) loadForecast(selectedId);
    }
  }, [selectedId, months, isCompare, showForecast, loadPrices, loadForecast]);

  useEffect(() => {
    if (isCompare && compareIds.length >= 2) loadComparison(compareIds);
  }, [compareIds, months, isCompare, loadComparison]);

  // Build combined chart data for comparison
  const comparisonChartData = (() => {
    if (!isCompare || Object.keys(compareData).length === 0) return [];
    const allDates = new Set<string>();
    Object.values(compareData).forEach((pts) => pts.forEach((p) => allDates.add(p.date)));
    return Array.from(allDates).sort().map((date) => {
      const point: Record<string, string | number> = { date };
      Object.entries(compareData).forEach(([name, pts]) => {
        const found = pts.find((p) => p.date === date);
        if (found) point[name] = found.price;
      });
      return point;
    });
  })();

  // Merge actual + forecast
  const chartData = showForecast
    ? [
        ...prices.map((p) => ({ ...p, type: "actual" })),
        ...forecasts.map((f) => ({ date: f.date, price: f.price, confidenceLow: f.confidence_low, confidenceHigh: f.confidence_high, type: "forecast" })),
      ]
    : prices;

  const selectedChem = chemicals.find((c) => c.id === selectedId);

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Price Intelligence</h1>
            <p className="text-slate-500 text-sm mt-1">Historical prices, trends & AI forecasts</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setIsCompare(false)}
              className={isCompare ? "btn-secondary" : "btn-primary"}
            >
              Single View
            </button>
            <button
              onClick={() => setIsCompare(true)}
              className={isCompare ? "btn-primary" : "btn-secondary"}
            >
              Compare
            </button>
          </div>
        </div>

        {!isCompare ? (
          <>
            {/* Controls */}
            <div className="card">
              <div className="flex flex-wrap gap-4 items-end">
                <div className="flex-1 min-w-[200px]">
                  <label className="block text-xs font-medium text-slate-600 mb-1">Chemical</label>
                  <select
                    className="input-field"
                    value={selectedId || ""}
                    onChange={(e) => setSelectedId(Number(e.target.value))}
                  >
                    {chemicals.map((c) => (
                      <option key={c.id} value={c.id}>{c.name} ({c.country})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Period</label>
                  <select className="input-field" value={months} onChange={(e) => setMonths(Number(e.target.value))}>
                    <option value={6}>6 Months</option>
                    <option value={12}>1 Year</option>
                    <option value={24}>2 Years</option>
                    <option value={36}>3 Years</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Chart Type</label>
                  <select className="input-field" value={chartType} onChange={(e) => setChartType(e.target.value as "line" | "area" | "bar")}>
                    <option value="area">Area</option>
                    <option value="line">Line</option>
                    <option value="bar">Bar</option>
                  </select>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="forecast"
                    checked={showForecast}
                    onChange={(e) => setShowForecast(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <label htmlFor="forecast" className="text-sm text-slate-700">Show Forecast</label>
                </div>
              </div>
            </div>

            {/* Stats */}
            {stats && (
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                {[
                  { label: "Current Price", value: `$${stats.latest_price?.toFixed(2)}` },
                  { label: "Avg Price (12M)", value: `$${stats.avg_price?.toFixed(2)}` },
                  { label: "Min Price (12M)", value: `$${stats.min_price?.toFixed(2)}` },
                  { label: "Max Price (12M)", value: `$${stats.max_price?.toFixed(2)}` },
                  { label: "CAGR", value: cagr ? `${cagr}%` : "N/A" },
                ].map((s) => (
                  <div key={s.label} className="bg-white rounded-lg border border-slate-200 p-3">
                    <p className="text-xs text-slate-500">{s.label}</p>
                    <p className="text-lg font-bold text-slate-800 mt-0.5">{s.value}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Chart */}
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-slate-800">
                  {selectedChem?.name} Price Chart
                  {selectedChem && <span className="text-slate-400 text-sm font-normal ml-2">USD/{selectedChem.unit}</span>}
                </h2>
                {showForecast && forecastMeta && (
                  <div className="flex gap-3 text-xs">
                    <span className={`badge ${forecastMeta.trendDirection === "Bullish" ? "bg-green-100 text-green-700" : forecastMeta.trendDirection === "Bearish" ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-600"}`}>
                      {forecastMeta.trendDirection}
                    </span>
                    <span className="badge bg-purple-100 text-purple-700">Accuracy: {forecastMeta.accuracy}</span>
                  </div>
                )}
              </div>

              {loading ? (
                <div className="h-64 flex items-center justify-center text-slate-400">Loading chart...</div>
              ) : (
                <ResponsiveContainer width="100%" height={380}>
                  {chartType === "bar" ? (
                    <BarChart data={prices}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => v.slice(0, 7)} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v: number) => [`$${v.toFixed(2)}`, "Price"]} labelFormatter={(l) => l.slice(0, 7)} />
                      <Bar dataKey="price" fill="#3b82f6" name="Price" radius={[2, 2, 0, 0]} />
                    </BarChart>
                  ) : chartType === "line" ? (
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => v.slice(0, 7)} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v: number) => [`$${v.toFixed(2)}`]} labelFormatter={(l) => l.slice(0, 7)} />
                      <Legend />
                      <Line type="monotone" dataKey="price" stroke="#3b82f6" dot={false} strokeWidth={2} name="Price" />
                      <Line type="monotone" dataKey="ma3" stroke="#10b981" dot={false} strokeWidth={1.5} strokeDasharray="4 4" name="3M MA" />
                      {showForecast && <Line type="monotone" dataKey="price" stroke="#f59e0b" dot={false} strokeWidth={2} strokeDasharray="6 3" name="Forecast" />}
                      {showForecast && prices.length > 0 && (
                        <ReferenceLine x={prices[prices.length - 1]?.date} stroke="#94a3b8" strokeDasharray="4 4" label={{ value: "Today", fontSize: 10 }} />
                      )}
                    </LineChart>
                  ) : (
                    <AreaChart data={chartData}>
                      <defs>
                        <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => v.slice(0, 7)} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v: number) => [`$${v.toFixed(2)}`]} labelFormatter={(l) => l.slice(0, 7)} />
                      <Legend />
                      <Area type="monotone" dataKey="price" stroke="#3b82f6" fill="url(#priceGrad)" strokeWidth={2} name="Price" />
                      <Line type="monotone" dataKey="ma3" stroke="#10b981" dot={false} strokeWidth={1.5} strokeDasharray="4 4" name="3M MA" />
                      {showForecast && (
                        <Area type="monotone" dataKey="confidenceHigh" stroke="none" fill="#f59e0b" fillOpacity={0.1} name="Confidence Band" />
                      )}
                    </AreaChart>
                  )}
                </ResponsiveContainer>
              )}
            </div>

            {/* Forecast table */}
            {showForecast && forecasts.length > 0 && (
              <div className="card">
                <h2 className="font-semibold text-slate-800 mb-4">AI Price Forecast — {selectedChem?.name}</h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-100">
                        <th className="table-header">Month</th>
                        <th className="table-header">Forecast Date</th>
                        <th className="table-header">Price (USD/MT)</th>
                        <th className="table-header">Low Estimate</th>
                        <th className="table-header">High Estimate</th>
                        <th className="table-header">Change</th>
                      </tr>
                    </thead>
                    <tbody>
                      {forecasts.map((f) => {
                        const change = forecastMeta ? ((f.price - forecastMeta.lastPrice) / forecastMeta.lastPrice * 100).toFixed(1) : null;
                        return (
                          <tr key={f.month} className="border-b border-slate-50">
                            <td className="table-cell font-medium">+{f.month}M</td>
                            <td className="table-cell">{f.date.slice(0, 7)}</td>
                            <td className="table-cell font-bold text-slate-800">${f.price.toFixed(2)}</td>
                            <td className="table-cell text-red-600">${f.confidence_low.toFixed(2)}</td>
                            <td className="table-cell text-green-600">${f.confidence_high.toFixed(2)}</td>
                            <td className="table-cell">
                              {change && (
                                <span className={`badge ${Number(change) > 0 ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                                  {Number(change) > 0 ? "+" : ""}{change}%
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        ) : (
          /* Compare Mode */
          <div className="space-y-4">
            <div className="card">
              <h2 className="font-semibold text-slate-800 mb-3">Select Chemicals to Compare</h2>
              <div className="flex flex-wrap gap-2">
                {chemicals.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      setCompareIds((prev) =>
                        prev.includes(c.id) ? prev.filter((x) => x !== c.id) : [...prev, c.id].slice(0, 5)
                      );
                    }}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
                      compareIds.includes(c.id)
                        ? "bg-blue-600 text-white border-blue-600"
                        : "bg-white text-slate-700 border-slate-300 hover:border-blue-400"
                    }`}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-400 mt-2">Select 2–5 chemicals to compare</p>
            </div>

            {comparisonChartData.length > 0 && (
              <div className="card">
                <h2 className="font-semibold text-slate-800 mb-4">Price Comparison Chart</h2>
                <ResponsiveContainer width="100%" height={380}>
                  <LineChart data={comparisonChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => v.slice(0, 7)} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip formatter={(v: number) => [`$${v.toFixed(2)}`]} labelFormatter={(l) => l.slice(0, 7)} />
                    <Legend />
                    {Object.keys(compareData).map((name, i) => (
                      <Line key={name} type="monotone" dataKey={name} stroke={COLORS[i % COLORS.length]} dot={false} strokeWidth={2} />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {compareIds.length < 2 && (
              <div className="card text-center py-12 text-slate-400">
                Select at least 2 chemicals above to see comparison chart
              </div>
            )}
          </div>
        )}
      </div>
    </AppLayout>
  );
}

export default function ChemicalsPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-slate-400">Loading...</div>}>
      <ChemicalsPageInner />
    </Suspense>
  );
}
