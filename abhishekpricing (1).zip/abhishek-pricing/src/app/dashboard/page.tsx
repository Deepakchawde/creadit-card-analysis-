"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout";
import Link from "next/link";

interface Chemical {
  id: number;
  name: string;
  category: string;
  country: string;
  currency: string;
  unit: string;
  latest_price: number;
  latest_date: string;
  data_points: number;
}

function StatCard({ label, value, sub, color }: { label: string; value: string | number; sub?: string; color: string }) {
  return (
    <div className="card">
      <p className="text-sm text-slate-500 font-medium">{label}</p>
      <p className={`text-3xl font-bold mt-1 ${color}`}>{value}</p>
      {sub && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
    </div>
  );
}

export default function DashboardPage() {
  const [chemicals, setChemicals] = useState<Chemical[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    fetch("/api/chemicals", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((d) => { setChemicals(d.chemicals || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const totalDataPoints = chemicals.reduce((s, c) => s + (c.data_points || 0), 0);

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Market Dashboard</h1>
          <p className="text-slate-500 text-sm mt-1">Real-time chemical pricing intelligence</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Chemicals Tracked" value={chemicals.length} sub="Across all regions" color="text-blue-600" />
          <StatCard label="Price Records" value={totalDataPoints.toLocaleString()} sub="Historical data points" color="text-green-600" />
          <StatCard label="Categories" value={new Set(chemicals.map(c => c.category)).size} sub="Chemical segments" color="text-purple-600" />
          <StatCard label="Countries" value={new Set(chemicals.map(c => c.country)).size} sub="Geographic coverage" color="text-orange-600" />
        </div>

        {/* Price Table */}
        <div className="card p-0 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
            <h2 className="font-semibold text-slate-800">Latest Chemical Prices</h2>
            <Link href="/chemicals" className="text-blue-600 text-sm hover:underline">View Charts →</Link>
          </div>
          {loading ? (
            <div className="p-8 text-center text-slate-400">Loading prices...</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-100">
                    <th className="table-header">Chemical</th>
                    <th className="table-header">Category</th>
                    <th className="table-header">Country</th>
                    <th className="table-header text-right">Price (USD/MT)</th>
                    <th className="table-header">Last Updated</th>
                    <th className="table-header">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {chemicals.map((c) => (
                    <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50">
                      <td className="table-cell font-semibold text-slate-800">{c.name}</td>
                      <td className="table-cell">
                        <span className="badge bg-blue-100 text-blue-700">{c.category}</span>
                      </td>
                      <td className="table-cell">{c.country}</td>
                      <td className="table-cell text-right font-bold text-slate-800">
                        ${c.latest_price ? c.latest_price.toFixed(2) : "—"}
                      </td>
                      <td className="table-cell text-slate-400 text-xs">{c.latest_date?.slice(0, 7) || "—"}</td>
                      <td className="table-cell">
                        <Link href={`/chemicals?id=${c.id}`} className="text-blue-600 text-xs hover:underline">
                          View Chart
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link href="/chemicals" className="card hover:shadow-md transition-shadow cursor-pointer group">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
                </svg>
              </div>
              <div>
                <p className="font-semibold text-slate-800">Price Charts</p>
                <p className="text-xs text-slate-500">Interactive price analysis</p>
              </div>
            </div>
          </Link>

          <Link href="/ai-assistant" className="card hover:shadow-md transition-shadow cursor-pointer group">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
              </div>
              <div>
                <p className="font-semibold text-slate-800">AI Market Analyst</p>
                <p className="text-xs text-slate-500">Ask market questions</p>
              </div>
            </div>
          </Link>

          <Link href="/chemicals?compare=1" className="card hover:shadow-md transition-shadow cursor-pointer group">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2" />
                </svg>
              </div>
              <div>
                <p className="font-semibold text-slate-800">Compare Chemicals</p>
                <p className="text-xs text-slate-500">Multi-chemical comparison</p>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </AppLayout>
  );
}
