"use client";
import { useEffect, useState, useRef } from "react";
import AppLayout from "@/components/AppLayout";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

interface Chemical {
  id: number;
  name: string;
}

const SUGGESTED = [
  "Why did Methanol prices increase recently?",
  "Forecast Acetic Acid for the next 6 months",
  "Explain supply chain disruptions in Asia",
  "How does crude oil impact chemical prices?",
  "Compare Ethylene and Propylene outlook",
  "What is the market sentiment for Benzene?",
];

function renderMarkdown(text: string) {
  return text
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/^## (.*$)/gm, "<h2>$1</h2>")
    .replace(/^### (.*$)/gm, "<h3>$1</h3>")
    .replace(/^\| (.*) \|$/gm, (match) => {
      const cells = match.split("|").filter(Boolean).map((c) => c.trim());
      return `<tr>${cells.map((c, i) => i === 0 ? `<td>${c}</td>` : `<td>${c}</td>`).join("")}</tr>`;
    })
    .replace(/^> (.*$)/gm, "<blockquote>$1</blockquote>")
    .replace(/^- (.*$)/gm, "<li>$1</li>")
    .replace(/^\d+\. (.*$)/gm, "<li>$1</li>")
    .replace(/\n\n/g, "<br/><br/>")
    .replace(/\n/g, "<br/>");
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "## Welcome to Abhishek AI Market Analyst\n\nI can help you with:\n\n- **Price Analysis** — Understand why prices moved\n- **Market Forecasts** — 1–12 month price predictions\n- **Supply Chain** — Disruptions, logistics, capacity\n- **Feedstock Impact** — How raw materials affect prices\n- **Geopolitical Effects** — Trade flows, sanctions, tariffs\n\nAsk me anything about chemical markets!",
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [chemicals, setChemicals] = useState<Chemical[]>([]);
  const [selectedChemId, setSelectedChemId] = useState<number | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : "";

  useEffect(() => {
    fetch("/api/chemicals", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((d) => setChemicals(d.chemicals || []));
  }, [token]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function sendMessage(question: string = input) {
    if (!question.trim() || loading) return;
    setInput("");
    const userMsg: Message = { role: "user", content: question, timestamp: new Date().toISOString() };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ question, chemicalId: selectedChemId }),
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.response, timestamp: data.timestamp },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Sorry, I encountered an error. Please try again.", timestamp: new Date().toISOString() },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-140px)] max-w-4xl mx-auto">
        <div className="mb-4">
          <h1 className="text-2xl font-bold text-slate-800">AI Market Analyst</h1>
          <p className="text-slate-500 text-sm mt-1">Powered by Abhishek AI — Chemical Intelligence Engine</p>
        </div>

        {/* Chemical context selector */}
        <div className="card mb-4 py-3">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-sm text-slate-600 font-medium">Chemical Context:</span>
            <select
              className="input-field w-auto flex-1 max-w-xs"
              value={selectedChemId || ""}
              onChange={(e) => setSelectedChemId(e.target.value ? Number(e.target.value) : null)}
            >
              <option value="">Auto-detect from question</option>
              {chemicals.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <span className="text-xs text-slate-400">Set this for more accurate price data in responses</span>
          </div>
        </div>

        {/* Chat area */}
        <div className="flex-1 card overflow-y-auto mb-4 space-y-4 p-4">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              {msg.role === "assistant" && (
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold mr-2 flex-shrink-0 mt-1">AI</div>
              )}
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                  msg.role === "user"
                    ? "bg-blue-600 text-white"
                    : "bg-slate-50 border border-slate-200"
                }`}
              >
                {msg.role === "assistant" ? (
                  <div
                    className="prose-dark text-sm"
                    dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }}
                  />
                ) : (
                  <p className="text-sm">{msg.content}</p>
                )}
                <p className={`text-xs mt-2 ${msg.role === "user" ? "text-blue-200" : "text-slate-400"}`}>
                  {new Date(msg.timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold mr-2 flex-shrink-0">AI</div>
              <div className="bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <div key={i} className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Suggestions */}
        <div className="flex gap-2 flex-wrap mb-3">
          {SUGGESTED.slice(0, 3).map((s) => (
            <button
              key={s}
              onClick={() => sendMessage(s)}
              className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 px-3 py-1.5 rounded-full border border-blue-200 transition-colors"
            >
              {s}
            </button>
          ))}
        </div>

        {/* Input */}
        <div className="flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
            className="input-field flex-1"
            placeholder="Ask about chemical prices, forecasts, market trends..."
            disabled={loading}
          />
          <button
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            className="btn-primary px-5 disabled:opacity-50"
          >
            Send
          </button>
        </div>
      </div>
    </AppLayout>
  );
}
