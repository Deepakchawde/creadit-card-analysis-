import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { getTokenFromRequest } from "@/lib/auth";
import * as XLSX from "xlsx";

export async function POST(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user || !["superadmin", "analyst"].includes(user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;
    if (!file) return NextResponse.json({ error: "No file uploaded" }, { status: 400 });

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    let rows: { Date: string; Chemical: string; Price: number }[] = [];

    if (file.name.endsWith(".csv")) {
      const text = buffer.toString("utf-8");
      const lines = text.split("\n").filter(Boolean);
      const headers = lines[0].split(",").map((h) => h.trim());
      for (let i = 1; i < lines.length; i++) {
        const vals = lines[i].split(",").map((v) => v.trim());
        if (vals.length < 3) continue;
        rows.push({
          Date: vals[headers.indexOf("Date")] || vals[0],
          Chemical: vals[headers.indexOf("Chemical")] || vals[1],
          Price: parseFloat(vals[headers.indexOf("Price")] || vals[2]),
        });
      }
    } else {
      const workbook = XLSX.read(buffer, { type: "buffer" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      rows = XLSX.utils.sheet_to_json(sheet) as { Date: string; Chemical: string; Price: number }[];
    }

    const db = getDb();
    let inserted = 0;
    let skipped = 0;
    const errors: string[] = [];

    const insertPrice = db.prepare(
      "INSERT OR IGNORE INTO price_history (chemical_id, date, price) VALUES (?, ?, ?)"
    );

    const upsertChem = db.prepare(
      "INSERT OR IGNORE INTO chemicals (name, grade, country, region, currency, unit, category) VALUES (?, 'Commercial', 'Global', 'Global', 'USD', 'MT', 'Petrochemical')"
    );

    const getChem = db.prepare("SELECT id FROM chemicals WHERE name = ?");

    const insertMany = db.transaction(() => {
      for (const row of rows) {
        if (!row.Date || !row.Chemical || !row.Price) { skipped++; continue; }
        if (isNaN(row.Price) || row.Price <= 0) { errors.push(`Invalid price for ${row.Chemical}`); skipped++; continue; }

        let dateStr = String(row.Date).trim();
        // Handle Excel serial dates
        if (!isNaN(Number(dateStr))) {
          const d = XLSX.SSF.parse_date_code(Number(dateStr));
          dateStr = `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
        }

        upsertChem.run(row.Chemical.trim());
        const chem = getChem.get(row.Chemical.trim()) as { id: number } | undefined;
        if (!chem) { skipped++; continue; }

        const result = insertPrice.run(chem.id, dateStr, row.Price);
        if (result.changes > 0) inserted++;
        else skipped++;
      }
    });

    insertMany();

    db.prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)").run(
      user.userId, "data_upload", `Uploaded ${file.name}: ${inserted} rows inserted`
    );

    return NextResponse.json({
      message: "Upload complete",
      inserted,
      skipped,
      errors: errors.slice(0, 10),
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Upload failed: " + String(err) }, { status: 500 });
  }
}
