import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const db = getDb();
  const chemicals = db.prepare(`
    SELECT c.*,
      (SELECT price FROM price_history WHERE chemical_id = c.id ORDER BY date DESC LIMIT 1) as latest_price,
      (SELECT date FROM price_history WHERE chemical_id = c.id ORDER BY date DESC LIMIT 1) as latest_date,
      (SELECT COUNT(*) FROM price_history WHERE chemical_id = c.id) as data_points
    FROM chemicals c ORDER BY c.name
  `).all();

  return NextResponse.json({ chemicals });
}

export async function POST(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user || !["superadmin", "analyst"].includes(user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json();
  const { name, grade, country, region, currency, unit, category } = body;
  if (!name) return NextResponse.json({ error: "Name required" }, { status: 400 });

  const db = getDb();
  const result = db.prepare(
    "INSERT INTO chemicals (name, grade, country, region, currency, unit, category) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run(name, grade || "Commercial", country || "Global", region || "Global",
        currency || "USD", unit || "MT", category || "Petrochemical");

  db.prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)").run(
    user.userId, "chemical_added", `Added: ${name}`
  );

  return NextResponse.json({ id: result.lastInsertRowid, message: "Chemical added" }, { status: 201 });
}

export async function PUT(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user || !["superadmin", "analyst"].includes(user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json();
  const { id, name, grade, country, region, currency, unit, category } = body;
  if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

  const db = getDb();
  db.prepare(
    "UPDATE chemicals SET name=?, grade=?, country=?, region=?, currency=?, unit=?, category=? WHERE id=?"
  ).run(name, grade, country, region, currency, unit, category, id);

  return NextResponse.json({ message: "Updated" });
}

export async function DELETE(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user || user.role !== "superadmin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

  const db = getDb();
  db.prepare("DELETE FROM chemicals WHERE id = ?").run(id);
  return NextResponse.json({ message: "Deleted" });
}
