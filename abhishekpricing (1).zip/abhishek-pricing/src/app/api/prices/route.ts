import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { getTokenFromRequest } from "@/lib/auth";

interface PriceRow {
  date: string;
  price: number;
}

interface StatsRow {
  avg_price: number;
  min_price: number;
  max_price: number;
  latest_price: number;
}

export async function GET(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const chemicalId = searchParams.get("chemicalId");
  const months = parseInt(searchParams.get("months") || "24");
  const chemicalIds = searchParams.get("ids")?.split(",").filter(Boolean);

  const db = getDb();

  if (chemicalIds && chemicalIds.length > 0) {
    // Multi-chemical comparison
    const result: Record<string, { date: string; price: number }[]> = {};
    for (const id of chemicalIds) {
      const chem = db.prepare("SELECT name FROM chemicals WHERE id = ?").get(id) as { name: string } | undefined;
      if (!chem) continue;
      const prices = db.prepare(`
        SELECT date, price FROM price_history
        WHERE chemical_id = ? AND date >= date('now', '-${months} months')
        ORDER BY date ASC
      `).all(id) as PriceRow[];
      result[chem.name] = prices;
    }
    return NextResponse.json({ comparison: result });
  }

  if (!chemicalId) return NextResponse.json({ error: "chemicalId required" }, { status: 400 });

  const prices = db.prepare(`
    SELECT date, price FROM price_history
    WHERE chemical_id = ? AND date >= date('now', '-${months} months')
    ORDER BY date ASC
  `).all(chemicalId) as PriceRow[];

  const stats = db.prepare(`
    SELECT
      AVG(price) as avg_price,
      MIN(price) as min_price,
      MAX(price) as max_price,
      (SELECT price FROM price_history WHERE chemical_id = ? ORDER BY date DESC LIMIT 1) as latest_price
    FROM price_history WHERE chemical_id = ? AND date >= date('now', '-12 months')
  `).get(chemicalId, chemicalId) as StatsRow;

  // Calculate CAGR
  const allPrices = db.prepare(
    "SELECT price, date FROM price_history WHERE chemical_id = ? ORDER BY date ASC"
  ).all(chemicalId) as PriceRow[];

  let cagr = null;
  if (allPrices.length >= 12) {
    const first = allPrices[0].price;
    const last = allPrices[allPrices.length - 1].price;
    const years = allPrices.length / 12;
    cagr = ((Math.pow(last / first, 1 / years) - 1) * 100).toFixed(2);
  }

  // 3-month moving average
  const withMA = prices.map((p, i) => {
    if (i < 2) return { ...p, ma3: p.price };
    const avg = (prices[i].price + prices[i - 1].price + prices[i - 2].price) / 3;
    return { ...p, ma3: Math.round(avg * 100) / 100 };
  });

  return NextResponse.json({ prices: withMA, stats, cagr });
}
