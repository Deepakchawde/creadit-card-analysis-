import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { signToken } from "@/lib/auth";

interface UserRow {
  id: number;
  user_id: string;
  email: string | null;
  password_hash: string;
  role: string;
  name: string;
  active: number;
}

export async function POST(req: NextRequest) {
  try {
    const { userId, password } = await req.json();
    if (!userId || !password) {
      return NextResponse.json({ error: "User ID and password required" }, { status: 400 });
    }

    const db = getDb();
    const user = db
      .prepare("SELECT * FROM users WHERE (user_id = ? OR email = ?) AND active = 1")
      .get(userId, userId) as UserRow | undefined;

    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }

    const token = signToken({ userId: user.user_id, role: user.role, name: user.name });

    db.prepare("INSERT INTO audit_logs (user_id, action) VALUES (?, ?)").run(user.user_id, "login");

    const res = NextResponse.json({
      token,
      user: { userId: user.user_id, role: user.role, name: user.name, email: user.email },
    });
    res.cookies.set("token", token, { httpOnly: true, maxAge: 86400, path: "/" });
    return res;
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
