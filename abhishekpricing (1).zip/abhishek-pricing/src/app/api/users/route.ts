import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { getTokenFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user || user.role !== "superadmin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const db = getDb();
  const users = db.prepare(
    "SELECT id, user_id, email, role, name, active, created_at FROM users ORDER BY created_at DESC"
  ).all();

  return NextResponse.json({ users });
}

export async function POST(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user || user.role !== "superadmin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json();
  const { name, email, role, password } = body;
  if (!name || !role) return NextResponse.json({ error: "Name and role required" }, { status: 400 });

  const db = getDb();

  // Auto-generate user ID like ABP0001
  const count = (db.prepare("SELECT COUNT(*) as cnt FROM users").get() as { cnt: number }).cnt;
  const userId = `ABP${String(count).padStart(4, "0")}`;
  const rawPassword = password || `Pass@${Math.random().toString(36).slice(2, 8)}`;
  const hash = bcrypt.hashSync(rawPassword, 10);

  try {
    db.prepare(
      "INSERT INTO users (user_id, email, password_hash, role, name) VALUES (?, ?, ?, ?, ?)"
    ).run(userId, email || null, hash, role, name);

    db.prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)").run(
      user.userId, "user_created", `Created user: ${userId} (${role})`
    );

    return NextResponse.json({ userId, password: rawPassword, message: "User created" }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "User ID or email already exists" }, { status: 409 });
  }
}

export async function PUT(req: NextRequest) {
  const user = getTokenFromRequest(req);
  if (!user || user.role !== "superadmin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json();
  const { id, active, role, password } = body;
  if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

  const db = getDb();

  if (password) {
    const hash = bcrypt.hashSync(password, 10);
    db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, id);
  }

  if (active !== undefined) {
    db.prepare("UPDATE users SET active = ? WHERE id = ?").run(active ? 1 : 0, id);
  }

  if (role) {
    db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, id);
  }

  return NextResponse.json({ message: "User updated" });
}
