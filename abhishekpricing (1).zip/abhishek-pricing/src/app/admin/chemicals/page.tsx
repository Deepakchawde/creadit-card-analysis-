"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout";

interface Chemical {
  id: number;
  name: string;
  grade: string;
  country: string;
  region: string;
  currency: string;
  unit: string;
  category: string;
  latest_price: number;
  data_points: number;
}

const BLANK = { name: "", grade: "Commercial", country: "India", region: "Asia", currency: "USD", unit: "MT", category: "Petrochemical" };

export default function ChemicalsAdminPage() {
  const [chemicals, setChemicals] = useState<Chemical[]>([]);
  const [form, setForm] = useState(BLANK);
  const [editId, setEditId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [msg, setMsg] = useState("");
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : "";

  function load() {
    fetch("/api/chemicals", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((d) => setChemicals(d.chemicals || []));
  }

  useEffect(() => { load(); }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const method = editId ? "PUT" : "POST";
    const body = editId ? { ...form, id: editId } : form;
    const r = await fetch("/api/chemicals", {
      method,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
    const d = await r.json();
    setMsg(d.message || d.error);
    if (r.ok) { setForm(BLANK); setEditId(null); setShowForm(false); load(); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this chemical and all its price data?")) return;
    const r = await fetch(`/api/chemicals?id=${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    const d = await r.json();
    setMsg(d.message || d.error);
    if (r.ok) load();
  }

  function startEdit(c: Chemical) {
    setForm({ name: c.name, grade: c.grade, country: c.country, region: c.region, currency: c.currency, unit: c.unit, category: c.category });
    setEditId(c.id);
    setShowForm(true);
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Chemical Management</h1>
            <p className="text-slate-500 text-sm mt-1">{chemicals.length} chemicals configured</p>
          </div>
          <button onClick={() => { setForm(BLANK); setEditId(null); setShowForm(true); }} className="btn-primary">
            + Add Chemical
          </button>
        </div>

        {msg && (
          <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-2 rounded-lg text-sm">
            {msg}
          </div>
        )}

        {showForm && (
          <div className="card">
            <h2 className="font-semibold text-slate-800 mb-4">{editId ? "Edit Chemical" : "Add New Chemical"}</h2>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                ["Chemical Name", "name", "text"],
                ["Grade", "grade", "text"],
                ["Country", "country", "text"],
                ["Region", "region", "text"],
                ["Currency", "currency", "text"],
                ["Unit", "unit", "text"],
                ["Category", "category", "text"],
              ].map(([label, key, type]) => (
                <div key={key}>
                  <label className="block text-xs font-medium text-slate-600 mb-1">{label}</label>
                  <input
                    type={type}
                    className="input-field"
                    value={form[key as keyof typeof form]}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    required={key === "name"}
                  />
                </div>
              ))}
              <div className="flex items-end gap-2 col-span-full">
                <button type="submit" className="btn-primary">{editId ? "Update" : "Add"} Chemical</button>
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
              </div>
            </form>
          </div>
        )}

        <div className="card p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="table-header">Name</th>
                  <th className="table-header">Grade</th>
                  <th className="table-header">Country</th>
                  <th className="table-header">Category</th>
                  <th className="table-header">Unit</th>
                  <th className="table-header text-right">Latest Price</th>
                  <th className="table-header text-right">Data Points</th>
                  <th className="table-header">Actions</th>
                </tr>
              </thead>
              <tbody>
                {chemicals.map((c) => (
                  <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50">
                    <td className="table-cell font-semibold text-slate-800">{c.name}</td>
                    <td className="table-cell text-slate-500">{c.grade}</td>
                    <td className="table-cell">{c.country}</td>
                    <td className="table-cell">
                      <span className="badge bg-blue-100 text-blue-700">{c.category}</span>
                    </td>
                    <td className="table-cell">{c.currency}/{c.unit}</td>
                    <td className="table-cell text-right font-bold">
                      {c.latest_price ? `$${c.latest_price.toFixed(2)}` : "—"}
                    </td>
                    <td className="table-cell text-right">{c.data_points || 0}</td>
                    <td className="table-cell">
                      <div className="flex gap-2">
                        <button onClick={() => startEdit(c)} className="text-blue-600 hover:underline text-xs">Edit</button>
                        <button onClick={() => handleDelete(c.id)} className="text-red-600 hover:underline text-xs">Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
