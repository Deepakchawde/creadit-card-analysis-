"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout";

interface User {
  id: number;
  user_id: string;
  email: string | null;
  role: string;
  name: string;
  active: number;
  created_at: string;
}

const BLANK = { name: "", email: "", role: "user", password: "" };

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [form, setForm] = useState(BLANK);
  const [showForm, setShowForm] = useState(false);
  const [msg, setMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);
  const [newCredentials, setNewCredentials] = useState<{ userId: string; password: string } | null>(null);
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : "";

  function load() {
    fetch("/api/users", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((d) => setUsers(d.users || []))
      .catch(() => {});
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    const r = await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(form),
    });
    const d = await r.json();
    if (r.ok) {
      setMsg({ text: "User created successfully!", type: "success" });
      setNewCredentials({ userId: d.userId, password: d.password });
      setForm(BLANK);
      setShowForm(false);
      load();
    } else {
      setMsg({ text: d.error || "Failed", type: "error" });
    }
  }

  async function toggleActive(user: User) {
    await fetch("/api/users", {
      method: "PUT",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ id: user.id, active: !user.active }),
    });
    load();
  }

  const roleBadge = (role: string) => {
    const map: Record<string, string> = {
      superadmin: "bg-red-100 text-red-700",
      analyst: "bg-purple-100 text-purple-700",
      user: "bg-green-100 text-green-700",
    };
    return map[role] || "bg-slate-100 text-slate-700";
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">User Management</h1>
            <p className="text-slate-500 text-sm mt-1">{users.length} users registered</p>
          </div>
          <button onClick={() => setShowForm(true)} className="btn-primary">+ Create User</button>
        </div>

        {msg && (
          <div className={`px-4 py-3 rounded-lg text-sm border ${msg.type === "success" ? "bg-green-50 border-green-200 text-green-700" : "bg-red-50 border-red-200 text-red-700"}`}>
            {msg.text}
          </div>
        )}

        {newCredentials && (
          <div className="card border-2 border-blue-200 bg-blue-50">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-blue-800 mb-2">New User Credentials — Save These!</h3>
                <div className="bg-white rounded-lg p-4 font-mono text-sm space-y-1">
                  <p><span className="text-slate-500">User ID:</span> <strong className="text-blue-700">{newCredentials.userId}</strong></p>
                  <p><span className="text-slate-500">Password:</span> <strong className="text-blue-700">{newCredentials.password}</strong></p>
                </div>
                <p className="text-xs text-blue-600 mt-2">Share these credentials with the user. They can change the password after login.</p>
              </div>
              <button onClick={() => setNewCredentials(null)} className="text-slate-400 hover:text-slate-600 ml-4">✕</button>
            </div>
          </div>
        )}

        {showForm && (
          <div className="card">
            <h2 className="font-semibold text-slate-800 mb-4">Create New User</h2>
            <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Full Name *</label>
                <input className="input-field" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Email (optional)</label>
                <input type="email" className="input-field" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Role *</label>
                <select className="input-field" value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}>
                  <option value="user">User (View Only)</option>
                  <option value="analyst">Analyst (Upload + View)</option>
                  <option value="superadmin">Super Admin (Full Access)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Password (leave blank to auto-generate)</label>
                <input className="input-field" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} placeholder="Auto-generated if empty" />
              </div>
              <div className="flex gap-2 col-span-full">
                <button type="submit" className="btn-primary">Create User</button>
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
              </div>
            </form>
          </div>
        )}

        <div className="card p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="table-header">User ID</th>
                  <th className="table-header">Name</th>
                  <th className="table-header">Email</th>
                  <th className="table-header">Role</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Created</th>
                  <th className="table-header">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-slate-50 hover:bg-slate-50">
                    <td className="table-cell font-mono font-bold text-slate-800">{u.user_id}</td>
                    <td className="table-cell">{u.name}</td>
                    <td className="table-cell text-slate-500 text-xs">{u.email || "—"}</td>
                    <td className="table-cell">
                      <span className={`badge ${roleBadge(u.role)}`}>{u.role}</span>
                    </td>
                    <td className="table-cell">
                      <span className={`badge ${u.active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                        {u.active ? "Active" : "Disabled"}
                      </span>
                    </td>
                    <td className="table-cell text-xs text-slate-400">{u.created_at.slice(0, 10)}</td>
                    <td className="table-cell">
                      <button
                        onClick={() => toggleActive(u)}
                        className={`text-xs ${u.active ? "text-red-600" : "text-green-600"} hover:underline`}
                      >
                        {u.active ? "Disable" : "Enable"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
