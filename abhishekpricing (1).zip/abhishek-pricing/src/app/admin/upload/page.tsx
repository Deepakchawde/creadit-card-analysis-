"use client";
import { useState, useRef } from "react";
import AppLayout from "@/components/AppLayout";

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<{ inserted: number; skipped: number; errors: string[]; message: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : "";

  async function handleUpload() {
    if (!file) return;
    setLoading(true);
    setError("");
    setResult(null);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const r = await fetch("/api/upload", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      const d = await r.json();
      if (!r.ok) { setError(d.error || "Upload failed"); }
      else setResult(d);
    } catch {
      setError("Upload failed — check your file format");
    } finally {
      setLoading(false);
    }
  }

  const SAMPLE_CSV = `Date,Chemical,Price
2024-01-01,Methanol,345.50
2024-02-01,Methanol,352.00
2024-03-01,Methanol,341.75
2024-01-01,Ethanol,518.00
2024-02-01,Ethanol,525.50
2024-03-01,Ethanol,515.25`;

  function downloadSample() {
    const blob = new Blob([SAMPLE_CSV], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sample-price-data.csv";
    a.click();
  }

  return (
    <AppLayout>
      <div className="max-w-2xl space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Data Upload</h1>
          <p className="text-slate-500 text-sm mt-1">Import historical price data via CSV or Excel (.xlsx)</p>
        </div>

        {/* Format guide */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-slate-800">Required Format</h2>
            <button onClick={downloadSample} className="btn-secondary text-xs">Download Sample CSV</button>
          </div>
          <p className="text-sm text-slate-600 mb-3">Your file must have these column headers:</p>
          <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm text-green-400">
            <div className="text-slate-400 text-xs mb-1">CSV format:</div>
            <div>Date,Chemical,Price</div>
            <div>2024-01-01,Methanol,345.50</div>
            <div>2024-02-01,Methanol,352.00</div>
            <div>2024-01-01,Acetic Acid,478.00</div>
          </div>
          <ul className="mt-3 text-xs text-slate-500 space-y-1">
            <li>• <strong>Date</strong>: YYYY-MM-DD format (or Excel date serial)</li>
            <li>• <strong>Chemical</strong>: Name must match existing chemicals, or will be auto-created</li>
            <li>• <strong>Price</strong>: Numeric value in USD/MT (or configured currency)</li>
            <li>• Duplicates (same chemical + date) are automatically skipped</li>
          </ul>
        </div>

        {/* Upload area */}
        <div className="card">
          <h2 className="font-semibold text-slate-800 mb-4">Upload File</h2>
          <div
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer
              ${dragging ? "border-blue-400 bg-blue-50" : "border-slate-200 hover:border-blue-300"}`}
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              const f = e.dataTransfer.files[0];
              if (f) setFile(f);
            }}
            onClick={() => inputRef.current?.click()}
          >
            <input
              ref={inputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
            />
            <svg className="w-12 h-12 text-slate-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            {file ? (
              <div>
                <p className="font-medium text-slate-800">{file.name}</p>
                <p className="text-xs text-slate-400 mt-1">{(file.size / 1024).toFixed(1)} KB</p>
              </div>
            ) : (
              <div>
                <p className="text-slate-600 font-medium">Drag & drop or click to select</p>
                <p className="text-xs text-slate-400 mt-1">CSV or Excel (.xlsx) files only</p>
              </div>
            )}
          </div>

          {file && (
            <button onClick={handleUpload} disabled={loading} className="btn-primary w-full mt-4 py-3">
              {loading ? "Uploading & Processing..." : `Upload ${file.name}`}
            </button>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        {result && (
          <div className="card">
            <h2 className="font-semibold text-slate-800 mb-4">Upload Results</h2>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                <p className="text-3xl font-bold text-green-600">{result.inserted}</p>
                <p className="text-sm text-green-700 mt-1">Records Inserted</p>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-center">
                <p className="text-3xl font-bold text-slate-500">{result.skipped}</p>
                <p className="text-sm text-slate-600 mt-1">Skipped (duplicates)</p>
              </div>
            </div>
            {result.errors.length > 0 && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <p className="text-sm font-medium text-yellow-800 mb-1">Warnings:</p>
                {result.errors.map((e, i) => (
                  <p key={i} className="text-xs text-yellow-700">{e}</p>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
