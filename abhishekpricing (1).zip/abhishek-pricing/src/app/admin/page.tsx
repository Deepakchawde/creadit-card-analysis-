"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout";
import Link from "next/link";

interface Stats {
  chemicals: number;
  users: number;
  dataPoints: number;
}

export default function AdminPage() {
  const [stats, setStats] = useState<Stats>({ chemicals: 0, users: 0, dataPoints: 0 });
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : "";

  useEffect(() => {
    fetch("/api/chemicals", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((d) => {
        const chems = d.chemicals || [];
        const dp = chems.reduce((s: number, c: { data_points: number }) => s + (c.data_points || 0), 0);
        setStats((prev) => ({ ...prev, chemicals: chems.length, dataPoints: dp }));
      });
    fetch("/api/users", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json())
      .then((d) => setStats((prev) => ({ ...prev, users: (d.users || []).length })))
      .catch(() => {});
  }, [token]);

  const cards = [
    { label: "Total Chemicals", value: stats.chemicals, href: "/admin/chemicals", color: "blue", icon: "M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" },
    { label: "Total Users", value: stats.users, href: "/admin/users", color: "green", icon: "M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" },
    { label: "Price Records", value: stats.dataPoints.toLocaleString(), href: "/admin/upload", color: "purple", icon: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" },
    { label: "Upload Data", value: "Import", href: "/admin/upload", color: "orange", icon: "M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" },
  ];

  const colorMap: Record<string, string> = {
    blue: "bg-blue-500", green: "bg-green-500", purple: "bg-purple-500", orange: "bg-orange-500",
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Admin Dashboard</h1>
          <p className="text-slate-500 text-sm mt-1">Platform overview and management</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {cards.map((c) => (
            <Link key={c.label} href={c.href} className="card hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 ${colorMap[c.color]} rounded-xl flex items-center justify-center`}>
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={c.icon} />
                  </svg>
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-800">{c.value}</p>
              <p className="text-sm text-slate-500 mt-0.5">{c.label}</p>
            </Link>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link href="/admin/chemicals" className="card hover:shadow-md transition-shadow">
            <h3 className="font-semibold text-slate-800 mb-2">Manage Chemicals</h3>
            <p className="text-sm text-slate-500">Add, edit, or remove chemicals from the system. Configure grades, regions, and categories.</p>
            <span className="inline-block mt-3 text-blue-600 text-sm font-medium">Go to Chemicals →</span>
          </Link>
          <Link href="/admin/upload" className="card hover:shadow-md transition-shadow">
            <h3 className="font-semibold text-slate-800 mb-2">Upload Price Data</h3>
            <p className="text-sm text-slate-500">Import CSV or Excel files with historical pricing data. Auto-validates and removes duplicates.</p>
            <span className="inline-block mt-3 text-blue-600 text-sm font-medium">Upload Data →</span>
          </Link>
          <Link href="/admin/users" className="card hover:shadow-md transition-shadow">
            <h3 className="font-semibold text-slate-800 mb-2">User Management</h3>
            <p className="text-sm text-slate-500">Create user accounts, assign roles, reset passwords, and manage access control.</p>
            <span className="inline-block mt-3 text-blue-600 text-sm font-medium">Manage Users →</span>
          </Link>
        </div>
      </div>
    </AppLayout>
  );
}
