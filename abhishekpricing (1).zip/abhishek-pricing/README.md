# Abhishek Pricing — Chemical Market Intelligence Platform

AI-powered chemical pricing, forecasting, and market analysis platform similar to PriceWatch.ai and ChemAnalyst.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Open browser
open http://localhost:3000
```

## Login Credentials

| Role | User ID | Password |
|------|---------|----------|
| Super Admin | `ADMIN` | `admin123` |
| User | Create via Admin Panel | Auto-generated |

## Features

- **Price Intelligence** — Historical charts (line/area/bar), 3-month moving average, CAGR
- **AI Forecasts** — 1–6 month price forecasts with confidence intervals
- **Chemical Comparison** — Compare up to 5 chemicals on one chart
- **AI Market Analyst** — Ask natural language questions about chemical markets
- **Data Upload** — Import CSV or Excel price data files
- **User Management** — Create users with auto-generated IDs (ABP0001, ABP0002...)
- **Role-Based Access** — Super Admin, Analyst, User roles

## Navigation

| URL | Description |
|-----|-------------|
| `http://localhost:3000/login` | Login page |
| `http://localhost:3000/dashboard` | User dashboard |
| `http://localhost:3000/chemicals` | Price charts & forecasts |
| `http://localhost:3000/ai-assistant` | AI Market Analyst chat |
| `http://localhost:3000/admin` | Admin dashboard |
| `http://localhost:3000/admin/chemicals` | Manage chemicals |
| `http://localhost:3000/admin/upload` | Upload price data |
| `http://localhost:3000/admin/users` | Manage users |

## CSV Upload Format

```csv
Date,Chemical,Price
2024-01-01,Methanol,345.50
2024-02-01,Methanol,352.00
2024-01-01,Acetic Acid,478.00
```

## Pre-loaded Chemicals

- Methanol, Ethanol, Acetic Acid (Asia/India/China)
- Ethylene, Propylene (USA/Americas)
- Benzene, Toluene (Germany/Europe)
- Urea (India/Asia)

36 months of synthetic historical data auto-generated on first startup.

## Tech Stack

- **Frontend**: Next.js 15 + TypeScript + Tailwind CSS
- **Charts**: Recharts
- **Database**: SQLite (better-sqlite3) — zero setup required
- **Auth**: JWT + bcrypt + Role-Based Access Control
- **AI**: Built-in market intelligence engine (connect OpenAI key in .env.local for GPT integration)

## Environment Variables (.env.local)

```
JWT_SECRET=your-secret-key
DB_PATH=./abhishek-pricing.db
OPENAI_API_KEY=sk-... (optional, for GPT integration)
```
